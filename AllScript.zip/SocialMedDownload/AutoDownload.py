# import wget
# import os
# import webview


# html = """
# <!DOCTYPE html>
# <html>
# <head lang="en">
# <meta charset="UTF-8">

# <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
# <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


# <style>
#     #tsk{
#         color: #b5b8bd;
#         margin-top: 10px;
#     }

#     body{
#         background-color: #111317;
#         height: 300px;
#     }

#     #innerCard{
#         background-color: #282a2e;
#         margin-top: 25px; 
#         height: 205px;
#         margin-left: 22px;
#         margin-right: 22px;
#     }

#     #mainbtn{
#         margin-top: 10px;
#     }
# </style>
# </head>
# <body>

# <center><h1 id="tsk" class="text-warning">Video Downloader</h1></center>

# <center>
#     <div id="innerCard">
#         <div>
#             <br><br>
#             <div class="input-group mb-3 px-2">
#                 <span class="input-group-text" id="basic-addon1">Video Link</span>
#                 <input placeholder="Enter the video link" id="vidLink" type="text" class="form-control">
#             </div>
#             <button onclick="run()" type="button" class="btn btn-outline-warning btn-lg" id="hibtn">
#                 <span id="r">Run</span>
#                 <div class="spinner-border" role="status" id="w" style="display: none;">
#                     <span class="visually-hidden">Loading...</span>
#                 </div>
#             </button>
#         </div
#     </div>
# </center>

# <script>
#     function endsWith(str, suffix) {
#         return str.indexOf(suffix, str.length - suffix.length) !== -1;
#     }

#     function run() {
#         var vidLink = document.getElementById("vidLink").value;
#         if(vidLink.trim() != ""){ 
#             document.getElementById("w").style.display = 'block';
#             document.getElementById("r").style.display = 'none';
#             document.getElementById("hibtn").disabled = true;
#             pywebview.api.down(vidLink).then(showResponse);
#         }else{
#             alert("Fill the all required fields...");
#         }
        
#     }

#     function showResponse(response) {
#         alert(response);
#         document.getElementById("w").style.display = 'none';
#         document.getElementById("r").style.display = 'block';
#         document.getElementById("hibtn").disabled = false; 
#     }

# </script>
# </body>
# </html>
# """


# class Api:
#     def __init__(self):
#         self.link = ""

#     def down(self, vidLink):
#         self.link = vidLink
#         desk = os.path.abspath(os.path.expanduser("~/Desktop"))
#         wget.download(vidLink, desk)
#         return "Successfully Downloaded !!! Check the desktop..."
            
            


# if __name__ == '__main__':
#     api = Api()
#     window = webview.create_window('Task Store', html=html, js_api=api,  width=700, height=350)
#     webview.start()


# import sys
# import os
# import requests as r
# import wget
# filedir = os.path.join('C:/Users/varsh/Downloads')
# try:
#     LINK = "https://www.facebook.com/peopleareawesome/videos/637730157348346/" #url of video to be downloaded
#     html = r.get(LINK)
# except r.ConnectionError as e:
#     print("Error in connecting")
# except r.Timeout as e:
#     print("Timeout")
# except r.RequestException as e:
#     print("Invalid URL")
# except (KeyboardInterrupt, SystemExit):
#     print("System has quit")
#     sys.exit(1)
# except TypeError:
#     print("Video seems to be private ")
# else:
#     print("\n")
#     print("Video Quality:Normal " )
#     print("[+] Starting Download")
#     wget.download(LINK,filedir)
#     print("\n")
#     print("Video downloaded")


from pytube import YouTube
import os
yt = YouTube("https://www.youtube.com/shorts/PDBU0ONbi6I")
t = yt.streams.filter(progressive=True, file_extension='mp4')
print("[+] Downloading Started....")
t[0].download(os.path.abspath(os.path.expanduser("~/Desktop")))
print("[*] Completed !!!")