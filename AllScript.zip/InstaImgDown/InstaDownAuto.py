import webview
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import wget
import os





html = """
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


<style>
    #tsk{
        color: #b5b8bd;
        margin-top: 10px;
    }

    body{
        background-color: #111317;
        height: 400px;
    }

    #innerCard{
        background-color: #282a2e;
        margin-top: 25px; 
        height: 305px;
        margin-left: 22px;
        margin-right: 22px;
    }

    #mainbtn{
        margin-top: 10px;
    }
</style>
</head>
<body>

<center><h1 id="tsk" class="text-warning">Word Replacer</h1></center>

<center>
    <div id="innerCard">
        <div>
            <br><br>
            <div class="input-group mb-3 px-2">
                <span class="input-group-text" id="basic-addon1">Downloaded Image Location</span>
                <input placeholder="e,g. /home/usr/abc/" id="dir" type="text" class="form-control">
            </div>
            <div class="row px-5">
                <div class="col-md" style="width: 290px;">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">Username</span>
                        <input placeholder="Type here..." id="user" type="text" class="form-control">
                    </div>
                </div>
                <div class="col-md" style="width: 290px;">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">Password</span>
                        <input placeholder="Type here..." id="pwd" type="text" class="form-control">
                    </div>
                </div>
            </div>
            <div class="input-group mb-3 px-2">
                <span class="input-group-text" id="basic-addon1">Target Profile</span>
                <input placeholder="e,g. edward_snowden" id="target" type="text" class="form-control">
            </div>
            <button onclick="run()" type="button" class="btn btn-outline-warning btn-lg" id="hibtn">
                <span id="r">Run</span>
                <div class="spinner-border" role="status" id="w" style="display: none;">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </button>
        </div
    </div>
</center>

<script>
    function endsWith(str, suffix) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }

    function run() {
        var user = document.getElementById("user").value;
        var pwd = document.getElementById("pwd").value;
        var target = document.getElementById("target").value;
        var dir = document.getElementById("dir").value;
        if(endsWith(dir, "/")){
            if(dir.trim() != "" && user.trim() != "" && pwd.trim() != "" && target.trim() != ""){ 
                document.getElementById("w").style.display = 'block';
                document.getElementById("r").style.display = 'none';
                document.getElementById("hibtn").disabled = true;
                pywebview.api.apply(user, pwd, target, dir).then(showResponse);
            }else{
                alert("Fill the all required fields...");
            }
        }else{
            alert("Location must be ends with slash /");
        }
        
    }

    function showResponse(response) {
        alert(response);
        document.getElementById("w").style.display = 'none';
        document.getElementById("r").style.display = 'block';
        document.getElementById("hibtn").disabled = false; 
    }

</script>
</body>
</html>
"""


class InstaPhotoDownloader:
    def login_insta(self):
        self.driver.get("https://www.instagram.com/accounts/login/")
        time.sleep(2)

        usr = self.driver.find_element(by = By.CSS_SELECTOR, value = "._2hvTZ[name='username']")
        pwd = self.driver.find_element(by = By.CSS_SELECTOR, value = "._2hvTZ[name='password']")

        usr.send_keys(self.USERNAME)
        pwd.send_keys(self.PWD)
        pwd.send_keys(Keys.RETURN)

    def search_for_user(self):
        time.sleep(5)
        search_box = self.driver.find_element(by = By.CSS_SELECTOR, value = '.XTCLo[aria-label="Search Input"]')
        search_box.send_keys(self.PROFILE)
        search_box.send_keys(Keys.RETURN)

        time.sleep(2)
        self.driver.get(f"https://www.instagram.com/{self.PROFILE}/")


    def download_photos(self):
        # GET ALL PHOTOS
        images = self.driver.find_elements_by_tag_name('img')
        images = [image.get_attribute('src') for image in images]
        number = 0

        try:
            os.mkdir("./DownloadedImage")
        except:
            pass

        for image in images:
            save_as = os.path.join(f"{self.dir}DownloadedImage", str(number) + '.jpg')
            wget.download(image, save_as)
            number +=1

    def __init__(self):
        self.USERNAME = ""
        self.PWD = ""
        self.PROFILE = ""
        self.dir = ""

        try:
            self.driver = webdriver.Firefox()
        except:
            self.driver = webdriver.Chrome()

    def apply(self, user, pwd, target, dir):
        self.USERNAME = user
        self.PWD = pwd
        self.PROFILE = target
        self.dir = dir

        self.driver.maximize_window()
        self.login_insta()

        time.sleep(3)

        self.search_for_user()

        time.sleep(3)

        self.download_photos()

        return "Successfully Executed !!!"
            
            


if __name__ == '__main__':
    api = InstaPhotoDownloader()
    window = webview.create_window('Task Store', html=html, js_api=api,  width=700, height=450)
    webview.start()


# class InstaPhotoDownloader:
#     def login_insta(self):
#         self.driver.get("https://www.instagram.com/accounts/login/")
#         time.sleep(2)

#         usr = self.driver.find_element(by = By.CSS_SELECTOR, value = "._2hvTZ[name='username']")
#         pwd = self.driver.find_element(by = By.CSS_SELECTOR, value = "._2hvTZ[name='password']")

#         usr.send_keys(self.USERNAME)
#         pwd.send_keys(self.PWD)
#         pwd.send_keys(Keys.RETURN)

#     def search_for_user(self):
#         time.sleep(5)
#         search_box = self.driver.find_element(by = By.CSS_SELECTOR, value = '.XTCLo[aria-label="Search Input"]')
#         search_box.send_keys(self.PROFILE)
#         search_box.send_keys(Keys.RETURN)

#         time.sleep(2)
#         self.driver.get(f"https://www.instagram.com/{self.PROFILE}/")


#     def download_photos(self):
#         # GET ALL PHOTOS
#         images = self.driver.find_elements_by_tag_name('img')
#         images = [image.get_attribute('src') for image in images]
#         number = 0

#         try:
#             os.mkdir("./DownloadedImage")
#         except:
#             pass

#         for image in images:
#             save_as = os.path.join("./DownloadedImage/", str(number) + '.jpg')
#             wget.download(image, save_as)
#             number +=1

#         print("Done !!!!")

#     def __init__(self):
#         self.USERNAME = "team.taskstore@gmail.com"
#         self.PWD = "TaskStore@fb"
#         self.PROFILE = "edward_snowden"

#         try:
#             self.driver = webdriver.Firefox()
#         except:
#             self.driver = webdriver.Chrome()

#     def apply(self):

#         self.driver.maximize_window()
#         self.login_insta()

#         time.sleep(3)

#         self.search_for_user()

#         time.sleep(3)

#         self.download_photos()

# if __name__ == '__main__':
#     bot = InstaPhotoDownloader()
#     bot.apply()

