from selenium import webdriver
import time
import xlsxwriter
from selenium.webdriver.common.keys import Keys
import os
import webview



html = """
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


<style>
    #tsk{
        color: #b5b8bd;
        margin-top: 10px;
    }

    body{
        background-color: #111317;
        height: 250px;
    }

    #innerCard{
        background-color: #282a2e;
        margin-top: 15px; 
        height: 220px;
        margin-left: 22px;
        margin-right: 22px;
    }

    #mainbtn{
        margin-top: 10px;
    }
</style>
</head>
<body>

<center><h1 id="tsk">Extract From Flipkart</h1></center>

<center>
    <div id="innerCard">
        <div>
            <br>
            <div class="form-floating mx-3 mb-3">
                <input type="text" class="form-control" id="pro_name" placeholder="Enter the product name">
                <label for="pro_name">Product Name</label>
            </div>
            <button onclick="run()" id="mainbtn" type="button" class="btn btn-secondary btn-lg">
                <span id="r">Run</span>
                <div class="spinner-border" role="status" id="w" style="display: none">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </button>
        </div
    </div>
</center>

<script>

    function run() {
        var pro_name = document.getElementById("pro_name").value;
        if(pro_name.trim() != ""){
            document.getElementById("w").style.display = 'block';
            document.getElementById("r").style.display = 'none';
            document.getElementById("mainbtn").disabled = true; 
            pywebview.api.init(pro_name).then(showResponse);
        }else{
            alert("Please fill all fields...");
        }
    }

    function showResponse(response) {
        alert("Product details successfully extracted, check your desktop...");
        document.getElementById("w").style.display = 'none';
        document.getElementById("r").style.display = 'block';
        document.getElementById("mainbtn").disabled = false; 
    }

</script>
</body>
</html>
"""


class Api:
    def __init__(self):
        self.siteUrl = "https://www.flipkart.com"
        try:
            self.driver = webdriver.Firefox()
        except:
            self.driver = webdriver.Chrome()
        self.driver.maximize_window()

        #Initialize Information Category
        self.title=[]
        self.offer=[]
        self.originalPrice=[]
        self.productUrl=[]

        self.searchItem = ""
        self.move=1


    def init(self, searchName):
        self.searchItem = searchName

        self.sendRequest(self.siteUrl)

        self.searchYourItem()

        self.grabInformation()

        self.insertIntoExcel(self.title, self.offer, self.originalPrice, self.productUrl)
        return "done"

    def sendRequest(self, siteUrl):
        #Navigate to flipkart site
        self.driver.get(siteUrl)

        #Ignore the Login Part
        try:
            crossButton = self.driver.find_element_by_xpath("/html/body/div[2]/div/div/button")
            time.sleep(4)
            crossButton.click()
        except:
            print("An exception occured !!!")

    def searchYourItem(self):
        #Locate and click on the search bar
        searchBar = self.driver.find_element_by_xpath("//*[@id='container']/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input")
        searchBar.click()

        #Search Your item
        searchBar.send_keys(self.searchItem)
        searchBar.send_keys(Keys.ENTER)
        time.sleep(2)



    def grabInformation(self):
        time.sleep(5)
        global move

        allTitleClass = self.driver.find_elements_by_class_name("_4rR01T")
        allOfferPrice = self.driver.find_elements_by_class_name("_30jeq3")
        allOriginalPrice = self.driver.find_elements_by_class_name("_3I9_wc")
        allUrl = self.driver.find_elements_by_class_name("_1fQZEK")


        for i in allTitleClass:
            self.title.append(i.text)
            # print(i.text)

        for i in allOfferPrice:
            self.offer.append(i.text)
            # print(i.text)

        for i in allOriginalPrice:
            self.originalPrice.append(i.text)
            # print(i.text)

        for i in allUrl:
            myurl=i.get_attribute('href')
            self.productUrl.append(myurl)
            # print(i.text)


        if self.move<=2:
            self.move=self.move+1
            self.move_to_next_page()


    def move_to_next_page(self):
        next_page = self.driver.find_element_by_xpath("//*[@id='container']/div/div[3]/div[1]/div[2]/div[26]/div/div/nav/a[11]")
        next_page.click()

        time.sleep(3)
        self.grabInformation()


    def insertIntoExcel(self, title, offer, original, productUrl):
        row=1
        home = os.path.expanduser('~')
        location = os.path.join(home, 'Desktop')

        with xlsxwriter.Workbook(f"{location}/FlipkartScrappingData.xlsx") as workbook:
            workshit = workbook.add_worksheet()
            #Initialize the title
            workshit.write("A1", "Item Name")
            workshit.write("B1", "Offer Price")
            workshit.write("C1", "Orginal Price")
            workshit.write("D1", "Product URL")

            #Write Down the Information
            for n, m, a, u in zip(title, offer, original, productUrl):
                row=row+1
                workshit.write("A"+str(row), n)
                workshit.write("B"+str(row), m)
                workshit.write("C"+str(row), a)
                workshit.write("D"+str(row), u)

        # TO WRITE IN A SIMPLE TEXT FILE
        # home = os.path.expanduser('~')
        # location = os.path.join(home, 'Desktop')
        # with open(f"{location}/FlipkartScrappingData.txt", "a") as f:
        #     f.writelines(f"###########################################  Mobiles  ###########################################\n\n")
        #     f.write("Item Name \t\t\t\t Offer Price \t\t Original Price \t\t Product URL\n")
        #     for n, m, a, u in zip(title, offer, original, productUrl):
        #         f.write(f"{n} \t\t\t\t {m} \t\t {a} \t\t {u}\n")
        # END TO WRITE IN A SIMPLE TEXT FILE
                


if __name__ == '__main__':
    api = Api()
    window = webview.create_window('Task Store', html=html, js_api=api,  width=700, height=300)
    webview.start()



















# move=1

# def sendRequest(siteUrl):
#     #Navigate to flipkart site
#     driver.get(siteUrl)

#     #Ignore the Login Part
#     try:
#         crossButton = driver.find_element_by_xpath("/html/body/div[2]/div/div/button")
#         time.sleep(4)
#         crossButton.click()
#     except:
#         print("An exception occured !!!")

# def searchYourItem():
#     #Locate and click on the search bar
#     searchBar = driver.find_element_by_xpath("//*[@id='container']/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input")
#     searchBar.click()

#     #Search Your item
#     searchBar.send_keys("Mobiles")
#     searchBar.send_keys(Keys.ENTER)
#     time.sleep(2)



# def grabInformation():
#     time.sleep(5)
#     global move

#     allTitleClass = driver.find_elements_by_class_name("_4rR01T")
#     allOfferPrice = driver.find_elements_by_class_name("_30jeq3")
#     allOriginalPrice = driver.find_elements_by_class_name("_3I9_wc")
#     allUrl = driver.find_elements_by_class_name("_1fQZEK")


#     for i in allTitleClass:
#         title.append(i.text)
#         # print(i.text)

#     for i in allOfferPrice:
#         offer.append(i.text)
#         # print(i.text)

#     for i in allOriginalPrice:
#         originalPrice.append(i.text)
#         # print(i.text)

#     for i in allUrl:
#         myurl=i.get_attribute('href')
#         productUrl.append(myurl)
#         # print(i.text)


#     if move<=2:
#         move=move+1
#         move_to_next_page()


# def move_to_next_page():
#     next_page = driver.find_element_by_xpath("//*[@id='container']/div/div[3]/div[1]/div[2]/div[26]/div/div/nav/a[11]")
#     next_page.click()

#     time.sleep(3)
#     grabInformation()


# def insertIntoExcel(title, offer, original):
#     row=1
#     home = os.path.expanduser('~')
#     location = os.path.join(home, 'Desktop')

#     with xlsxwriter.Workbook(f"{location}/FlipkartScrappingData.xlsx") as workbook:
#         workshit = workbook.add_worksheet()
#         #Initialize the title
#         workshit.write("A1", "Item Name")
#         workshit.write("B1", "Offer Price")
#         workshit.write("C1", "Orginal Price")
#         workshit.write("D1", "Product URL")

#         #Write Down the Information
#         for n, m, a, u in zip(title, offer, original, productUrl):
#             row=row+1
#             workshit.write("A"+str(row), n)
#             workshit.write("B"+str(row), m)
#             workshit.write("C"+str(row), a)
#             workshit.write("D"+str(row), u)

#     # TO WRITE IN A SIMPLE TEXT FILE
#     # home = os.path.expanduser('~')
#     # location = os.path.join(home, 'Desktop')
#     # with open(f"{location}/FlipkartScrappingData.txt", "a") as f:
#     #     f.writelines(f"###########################################  Mobiles  ###########################################\n\n")
#     #     f.write("Item Name \t\t\t\t Offer Price \t\t Original Price \t\t Product URL\n")
#     #     for n, m, a, u in zip(title, offer, original, productUrl):
#     #         f.write(f"{n} \t\t\t\t {m} \t\t {a} \t\t {u}\n")
#     # END TO WRITE IN A SIMPLE TEXT FILE

# if __name__=="__main__":

#     # Take the site URL
#     siteUrl = "https://www.flipkart.com"
#     try:
#         driver = webdriver.Firefox()
#     except:
#         driver = webdriver.Chrome()
#     driver.maximize_window()


#     #Initialize Information Category
#     title=[]
#     offer=[]
#     originalPrice=[]
#     productUrl=[]


#     sendRequest(siteUrl)

#     searchYourItem()

#     grabInformation()

#     insertIntoExcel(title, offer, originalPrice)