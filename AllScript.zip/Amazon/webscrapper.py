from selenium import webdriver
import time
import xlsxwriter
from selenium.webdriver.common.keys import Keys
import os
from selenium.webdriver.common.by import By

move=1

def sendRequest(siteUrl):
    #Navigate to flipkart site
    driver.get(siteUrl)

def searchYourItem():
    searchBar = driver.find_element(by=By.ID, value="twotabsearchtextbox")
    searchBar.click()
    searchBar.send_keys("Realme Mobile")
    searchBar.send_keys(Keys.ENTER)



def grabInformation():
    global move
    # for i in range(2, 17):
        # allTitleClass = driver.find_element(by=By.XPATH, value=f"/html/body/div[1]/div[2]/div[1]/div[1]/div/span[3]/div[2]/div[{i}]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")
# /html/body/div[1]/div[2]/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span
# /html/body/div[1]/div[2]/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span
        # print(allTitleClass.text)
    
    allTitleClass = driver.find_elements(by=By.TAG_NAME, value="h2")
    for i in allTitleClass:
        print(i.text)
    # allTitleClass = driver.find_elements_by_class_name("_4rR01T")
    # allOfferPrice = driver.find_elements_by_class_name("_30jeq3")
    # allOriginalPrice = driver.find_elements_by_class_name("_3I9_wc")
    # allUrl = driver.find_elements_by_class_name("_1fQZEK")


    # for i in allTitleClass:
    #     title.append(i.text)
    #     # print(i.text)

    # for i in allOfferPrice:
    #     offer.append(i.text)
    #     # print(i.text)

    # for i in allOriginalPrice:
    #     originalPrice.append(i.text)
    #     # print(i.text)

    # for i in allUrl:
    #     myurl=i.get_attribute('href')
    #     productUrl.append(myurl)
    #     # print(i.text)


    # if move<=2:
    #     move=move+1
    #     move_to_next_page()


def move_to_next_page():
    next_page = driver.find_element_by_xpath("//*[@id='container']/div/div[3]/div[1]/div[2]/div[26]/div/div/nav/a[11]")
    next_page.click()

    time.sleep(3)
    grabInformation()


def insertIntoExcel(title, offer, original):
    row=1
    home = os.path.expanduser('~')
    location = os.path.join(home, 'Desktop')

    with xlsxwriter.Workbook(f"{location}/FlipkartScrappingData.xlsx") as workbook:
        workshit = workbook.add_worksheet()
        #Initialize the title
        workshit.write("A1", "Item Name")
        workshit.write("B1", "Offer Price")
        workshit.write("C1", "Orginal Price")
        workshit.write("D1", "Product URL")

        #Write Down the Information
        for n, m, a, u in zip(title, offer, original, productUrl):
            row=row+1
            workshit.write("A"+str(row), n)
            workshit.write("B"+str(row), m)
            workshit.write("C"+str(row), a)
            workshit.write("D"+str(row), u)

    # TO WRITE IN A SIMPLE TEXT FILE
    # home = os.path.expanduser('~')
    # location = os.path.join(home, 'Desktop')
    # with open(f"{location}/FlipkartScrappingData.txt", "a") as f:
    #     f.writelines(f"###########################################  Mobiles  ###########################################\n\n")
    #     f.write("Item Name \t\t\t\t Offer Price \t\t Original Price \t\t Product URL\n")
    #     for n, m, a, u in zip(title, offer, original, productUrl):
    #         f.write(f"{n} \t\t\t\t {m} \t\t {a} \t\t {u}\n")
    # END TO WRITE IN A SIMPLE TEXT FILE

if __name__=="__main__":

    # Take the site URL
    siteUrl = "https://www.amazon.com"
    try:
        driver = webdriver.Firefox()
    except:
        driver = webdriver.Chrome()
    driver.maximize_window()


    #Initialize Information Category
    title=[]
    offer=[]
    originalPrice=[]
    productUrl=[]

    sendRequest(siteUrl)

    time.sleep(5)
    searchYourItem()

    time.sleep(5)
    grabInformation()

    # insertIntoExcel(title, offer, originalPrice)