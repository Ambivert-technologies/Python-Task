import os
import subprocess

class MeanStack():
    def __init__(self):
        print("\n\n====================================================== STARTED ======================================================")
        self.system_codename = ""

    def getcodename(self):
        system_codename = subprocess.Popen(["lsb_release","-dc"], stdout=subprocess.PIPE)
        system_codename = str(system_codename.communicate()[0])[2:]
        system_codename = system_codename[:len(system_codename)-1]
        lts_index = str(system_codename).index("LTS")+5
        codename_with_dust = system_codename[lts_index:]
        tab_index = codename_with_dust.index("\\t")+2
        newline_index = codename_with_dust.index("\\n")
        self.system_codename = str(codename_with_dust[tab_index:newline_index]).lower()

    def installMongo(self):
        print("\n\n=========================================START OF MONGODB INSTALLATION==========================================")
        if self.system_codename == "focal":
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system("sudo apt-get install gnupg")
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system('echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list')
            os.system("sudo apt-get update")
            os.system("sudo apt-get install -y mongodb-org")
            os.system("sudo systemctl start mongod")
            os.system("sudo systemctl enable mongod")
                                    
        elif self.system_codename == "bionic":
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system("sudo apt-get install gnupg")
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system('echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu bionic/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list')
            os.system("sudo apt-get update")
            os.system("sudo apt-get install -y mongodb-org")
            os.system("sudo systemctl start mongod")
            os.system("sudo systemctl enable mongod")
                        
        elif self.system_codename == "xenial":
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system("sudo apt-get install gnupg")
            os.system("wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -")
            os.system('echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu xenial/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list')
            os.system("sudo apt-get update")
            os.system("sudo apt-get install -y mongodb-org")
            os.system("sudo systemctl start mongod")
            os.system("sudo systemctl enable mongod")
            
        else:
            print("Your os doesn't belongs to standard ubuntu distribution....")
        print("\n\n=========================================END OF MONGODB INSTALLATION==========================================")
        
    def installNPM(self):
        print("\n\n=========================================START OF NPM PACKAGES==========================================")
        # Install Node.js and npm
        os.system("sudo apt install curl")
        os.system("curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -")
        os.system("sudo apt install nodejs")
        os.system("node --version")
        os.system("npm --version")
        os.system("sudo apt install git")
        os.system("sudo npm install -g yarn")
        os.system("sudo npm install -g gulp")
        os.system("sudo npm -g bower")
        os.system("npm list -g -depth=0")
        print("\n\n=========================================NPM PACKAGES DONE==========================================")

    
    def installAngular(self):
        print("\n\n=========================================START OF ANGULARJS INSTALLATION==========================================")
        os.system("sudo npm install -g @angular/cli")
        try:
            os.system("ng --version")
        except:
            os.system("ng version")
        print("\n\n=========================================END OF ANGULARJS INSTALLATION==========================================")
        

    def installExp(self):
        print("\n\n=========================================START OF EXPRESSJS INSTALLATION==========================================")
        os.system("npm install express --save")
        print("\n\n=========================================END OF EXPRESSJS INSTALLATION==========================================")



if __name__ == '__main__':
    obj = MeanStack()
    obj.getcodename()
    obj.installNPM()
    obj.installMongo()
    obj.installExp()
    obj.installAngular()

