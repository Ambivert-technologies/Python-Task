import webview
import os
from PIL import Image

html = """
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


<style>
    #tsk{
        color: #b5b8bd;
        margin-top: 10px;
    }

    body{
        background-color: #111317;
        height: 400px;
    }

    #innerCard{
        background-color: #282a2e;
        margin-top: 25px; 
        height: 305px;
        margin-left: 22px;
        margin-right: 22px;
    }

    #mainbtn{
        margin-top: 10px;
    }
</style>
</head>
<body>

<center><h1 id="tsk" class="text-warning">Word Replacer</h1></center>

<center>
    <div id="innerCard">
        <div>
            <br><br>
            <div class="input-group mb-3 px-2">
                <span class="input-group-text" id="basic-addon1">Folder Path</span>
                <input placeholder="e,g. /home/usr/abc/" id="dir" type="text" class="form-control">
            </div>
            <div class="input-group mb-3 px-2">
                <span class="input-group-text" id="basic-addon1">Extension</span>
                <input placeholder="e,g. txt, py, docx" id="ext" type="text" class="form-control">
            </div>
            <div class="row px-5">
                <div class="col-md" style="width: 290px;">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">From</span>
                        <input placeholder="e,g. TaskStor" id="from" type="text" class="form-control">
                    </div>
                </div>
                <div class="col-md" style="width: 290px;">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">To</span>
                        <input placeholder="e,g. TaskStore" id="to" type="text" class="form-control">
                    </div>
                </div>
            </div>
            <button onclick="run()" type="button" class="btn btn-outline-warning btn-lg" id="hibtn">
                <span id="r">Run</span>
                <div class="spinner-border" role="status" id="w" style="display: none;">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </button>
        </div
    </div>
</center>

<script>
    function endsWith(str, suffix) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }

    function run() {
        var ext = document.getElementById("ext").value;
        var dir = document.getElementById("dir").value;
        var from = document.getElementById("from").value;
        var to = document.getElementById("to").value;
        if(endsWith(dir, "/")){
            if(dir.trim() != "" && ext.trim() != "" && from.trim() != "" && to.trim() != ""){ 
                document.getElementById("w").style.display = 'block';
                document.getElementById("r").style.display = 'none';
                document.getElementById("hibtn").disabled = true;
                pywebview.api.wordRep(ext, dir, from, to).then(showResponse);
            }else{
                alert("Fill the all required fields...");
            }
        }else{
            alert("Location must be ends with slash /");
        }
        
    }

    function showResponse(response) {
        alert(response);
        document.getElementById("w").style.display = 'none';
        document.getElementById("r").style.display = 'block';
        document.getElementById("hibtn").disabled = false; 
    }

</script>
</body>
</html>
"""


class Api:
    def __init__(self):
        self.required_op_dict = {}

    def wordRep(self, ext, dir, fromword, toword):
        # CLEAN EXTENSION
        cleanExt = []
        temp = str(ext).replace(", ", ",")
        extList = str(temp).replace(" ,", ",").split(",")
        for i in extList:
            if(i[0] != "."):
                i = "."+i
            cleanExt.append(i)

        # NOW GRAB REQUIRED FILE
        allFiles = os.listdir(dir)
        cleanFile = []
        for i in allFiles:
            fileName, fileExtension = os.path.splitext(i)
            if fileExtension in cleanExt:
                cleanFile.append(i)

        affectedFiles = []
        for i in cleanFile:
            if i != "AffectedLogFiles.txt":
                affectedFiles.append(i)
            with open(f"{dir}{i}", "r") as f:
                txt = f.read()
                txt = txt.replace(fromword, toword)
            with open(f"{dir}{i}", "w") as f:
                f.write(txt)
        try:
            os.remove(f"{dir}AffectedLogFiles.txt")
        except:
            pass

        for i in affectedFiles:
            with open(f"{dir}AffectedLogFiles.txt", "a") as f:
                    f.write("##################################################################################################################\n\n")
                    f.write(f"=====> {dir}{i}\n\n")
        
        return "Successfully Executed !!! Check the 'AffectedLogFiles.txt' ..."
            
            


if __name__ == '__main__':
    api = Api()
    window = webview.create_window('Task Store', html=html, js_api=api,  width=700, height=450)
    webview.start()
