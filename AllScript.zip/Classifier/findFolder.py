import os

home = os.path.expanduser('~')
for i in os.walk(home):
    print(i)