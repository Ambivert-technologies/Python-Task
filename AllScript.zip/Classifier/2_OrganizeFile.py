import webview
import os
import shutil
import time
#from tkinter import Tk, filedialog
# import easygui

html = """
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


<style>
    #tsk{
        color: #b5b8bd;
        margin-top: 10px;
    }

    body{
        background-color: #111317;
        height: 250px;
    }

    #innerCard{
        background-color: #282a2e;
        margin-top: 15px; 
        height: 220px;
        margin-left: 22px;
        margin-right: 22px;
    }

    #mainbtn{
        margin-top: 10px;
    }
</style>
</head>
<body>

<center><h1 id="tsk">Task Store</h1></center>

<center>
    <div id="innerCard">
        <div>
            <br>
            <select onchange="gettype(this.value)" class="mx-3 mb-3" style="padding-top: 12px; padding-bottom: 12px; width: 90%; border-radius: 10px;" id="type1">
                <option selected>Choose Directory/Folder</option>
                <option value="1">Default (Downloads)</option>
                <option value="2">Custom Path</option>
            </select>
            <div class="form-floating mx-3 mb-3" id="type2" style="display: none;">
                <input type="text" class="form-control" id="dir" placeholder="Enter the directory/Folder name">
                <label for="dir">Paste Directory/Folder name</label>
            </div>
            <div class="form-floating mx-3">
                <input type="text" class="form-control" id="kw" placeholder="e.g, .mp3, .jpg">
                <label for="kw">Enter the keywords</label>
            </div>
            <button onclick="run()" id="mainbtn" type="button" class="btn btn-secondary btn-lg">
                <span id="r">Run</span>
                <div class="spinner-border" role="status" id="w" style="display: none">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </button>
        </div
    </div>
</center>

<script>
    function gettype(val){
        if(val === "2"){
            document.getElementById("type2").style.display = 'block';
            document.getElementById("type1").style.display = 'none';
        }
    }

    function run() {
        var kw = document.getElementById("kw").value;
        var dir = "";
        if(document.getElementById("type1").value === "1"){
            dir = "Downloads";
        }else{
            dir = document.getElementById("dir").value;
        }
        if(kw.trim() != "" && dir.trim() != ""){
            document.getElementById("w").style.display = 'block';
            document.getElementById("r").style.display = 'none';
            document.getElementById("mainbtn").disabled = true; 
            pywebview.api.getFile(kw, dir).then(showResponse);
        }else{
            alert("Please fill all fields...");
        }
    }

    function showResponse(response) {
        alert("All files are organized properly...");
        document.getElementById("w").style.display = 'none';
        document.getElementById("r").style.display = 'block';
        document.getElementById("mainbtn").disabled = false; 
    }

</script>
</body>
</html>
"""


class Api:
    def __init__(self):
        self.DIR = ""

    def getFolder(self):
        # open_file = easygui.diropenbox()
        # open_file = easygui.fileopenbox()
        # root = Tk()
        # root.withdraw()
        # root.attributes('-topmost', True)
        # open_file = filedialog.askdirectory()
        self.DIR = "Downloads"
        return self.DIR

    def getFile(self, kw, dir):
        if dir == "Downloads":
            home = os.path.expanduser('~')
            dir = os.path.join(home, 'Downloads')
        temp = str(kw).replace(", ", ",")
        entered_keywords = str(temp).replace(" ,", ",").split(",")

        for i in entered_keywords:
            i = str(i).replace(".", "_")
            if os.path.isdir(f"{dir}/TaskStore/{i}"):
                pass
            else:
                if os.path.isdir(f"{dir}/TaskStore"):
                    pass
                else:
                    os.mkdir(f"{dir}/TaskStore")
                os.mkdir(f"{dir}/TaskStore/{i}")

        currentList = os.listdir(f"{dir}/")

        for cl in currentList:
            for ek in entered_keywords:
                if ek in cl:
                    ek = str(ek).replace(".", "_")
                    src_path = f"{dir}/{cl}"
                    dst_path = f"{dir}/TaskStore/{ek}/"
                    shutil.move(src_path, dst_path)
        time.sleep(2)
        return "done"
            


if __name__ == '__main__':
    api = Api()
    window = webview.create_window('Task Store', html=html, js_api=api,  width=700, height=300)
    webview.start()
