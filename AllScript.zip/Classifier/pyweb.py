#!/usr/bin/env python3
import webview
webview.create_window('Hello world', 'https://pywebview.flowrl.com/')
webview.start()