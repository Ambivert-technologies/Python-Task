import folium
import phonenumbers
from phonenumbers import geocoder
from phonenumbers import carrier
from opencage.geocoder import OpenCageGeocode

num_var = "+917797960271"
GEO_API_KEY = "705d1683dc9d4d4f99963dc3ad649062"
number = phonenumbers.parse(num_var, None)
country = geocoder.description_for_number(number, "en")
print(country)
service_provider = carrier.name_for_number(number, "en")
print(service_provider)
geocoder = OpenCageGeocode(GEO_API_KEY)
query = str(country)
results = geocoder.geocode(query)
lat = results[0]['geometry']['lat']
long = results[0]['geometry']['lng']
my_map3 = folium.Map(location = [lat, long], zoom_start = 15)
folium.Marker([lat, long], popup = 'SIM Location').add_to(my_map3)
my_map3.save("./my_map.html")