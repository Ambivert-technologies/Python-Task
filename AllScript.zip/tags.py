import tkinter as tk
import tkinter.font as tkFont

class App:
    def __init__(self, root):
        #setting title
        root.title("undefined")
        #setting window size
        width=600
        height=500
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        GButton_723=tk.Button(root)
        GButton_723["bg"] = "#e9e9ed"
        ft = tkFont.Font(family='Times',size=10)
        GButton_723["font"] = ft
        GButton_723["fg"] = "#000000"
        GButton_723["justify"] = "center"
        GButton_723["text"] = "Button"
        GButton_723.place(x=130,y=210,width=115,height=42)
        GButton_723["command"] = self.GButton_723_command

    def GButton_723_command(self):
        print("command")

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
